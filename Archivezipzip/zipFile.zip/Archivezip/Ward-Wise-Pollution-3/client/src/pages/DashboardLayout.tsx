import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { ClimateClock } from "@/components/ClimateClock";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Button } from "@/components/ui/button";
import { Wind, Home, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

interface DashboardLayoutProps {
  children: ReactNode;
  role: "citizen" | "authority";
}

export default function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col bg-background transition-colors duration-500">
      <ThemeToggle currentRole={role} />
      
      {/* Header */}
      <header className="border-b border-border sticky top-0 z-50 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className={cn(
                "w-8 h-8 rounded-lg flex items-center justify-center text-white",
                role === "citizen" ? "bg-primary" : "bg-blue-600"
              )}>
                <Wind className="w-5 h-5" />
              </div>
              <span className="font-display font-bold text-xl hidden md:inline">PollutionGuard</span>
            </Link>
            <div className="h-6 w-[1px] bg-border mx-2" />
            <span className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
              {role === "citizen" ? "Citizen Portal" : "Authority Command"}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <ClimateClock className="hidden md:flex" />
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-2">
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Exit</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>
    </div>
  );
}
