import { type Ward, type User, type InsertUser, type Report, type InsertReport } from "@shared/schema";
import fs from "fs";
import path from "path";
import * as turf from "@turf/turf";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getWards(): Promise<Ward[]>;
  getWard(id: number): Promise<Ward | undefined>;
  updateWard(id: number, ward: Partial<Ward>): Promise<Ward>;
  getLastUpdated(): Promise<Date>;

  // Reports
  createReport(report: InsertReport): Promise<Report>;
  getReportsByWard(wardId: number): Promise<Report[]>;
  updateReportVerification(id: number, verified: boolean): Promise<Report>;
}

export class MemStorage implements IStorage {
  private users = new Map<string, User>();
  private wards = new Map<number, Ward>();
  private reports = new Map<number, Report>();
  private reportIdCounter = 1;
  private lastUpdated = new Date();

  constructor() {
    this.loadGeoJSON();
    this.updatePollutionData();
    // Refresh from API every 3 minutes (rate-limit safe)
    setInterval(() => this.updatePollutionData(), 3 * 60 * 1000); 
  }

  private loadGeoJSON() {
    const geojsonPath = path.resolve(
      process.cwd(),
      "attached_assets/Delhi_Wards_1768070860005.geojson",
    );

    if (!fs.existsSync(geojsonPath)) {
      console.error("GeoJSON file not found at:", geojsonPath);
      return;
    }

    const data = fs.readFileSync(geojsonPath, "utf8");
    const geojson = JSON.parse(data);

    geojson.features.forEach((feature: any, index: number) => {
      const id = index + 1;
      // Use Turf to get the actual centroid of the ward
      const center = turf.centroid(feature);
      const [lng, lat] = center.geometry.coordinates;

      this.wards.set(id, {
        id,
        name: feature.properties.Ward_Name ?? `Ward ${id}`,
        latitude: lat,
        longitude: lng,
        aqi: 0,
        pm25: 0,
        pm10: 0,
        no2: 0,
        wprs: 0,
        co2_budget_remaining: 5000,
        emergency_mode: false,
        active_controls: [],
        dominant_source: "Traffic",
        mitigation_effort: 0,
        citizen_credits: 0,
      });
    });
  }

  public async updatePollutionData() {
    const token = process.env.AQICN_API_KEY;
    if (!token) {
      console.warn("AQICN_API_KEY not found, skipping update.");
      return;
    }

    console.log(`[AQI] Starting ward-centric update for ${this.wards.size} wards...`);

    // To respect rate limits and fulfill the "estimated" requirement, 
    // we fetch each ward. Since there are ~290 wards, calling them all at once 
    // might hit rate limits. However, the user asked for ward-centric feed calls.
    
    const updatedWards = new Map<number, Ward>();
    
    for (const [id, ward] of this.wards) {
      try {
        const url = `https://api.waqi.info/feed/geo:${ward.latitude};${ward.longitude}/?token=${token}`;
        const res = await fetch(url);
        const json = await res.json();

        if (json.status === "ok" && json.data?.aqi && json.data.aqi !== "-") {
          const aqi = Number(json.data.aqi);
          const updatedWard = {
            ...ward,
            aqi,
            pm25: json.data.iaqi?.pm25?.v ?? (aqi * 0.6),
            pm10: json.data.iaqi?.pm10?.v ?? (aqi * 0.8),
            no2: json.data.iaqi?.no2?.v ?? (aqi * 0.1),
            wprs: Math.max(0, 100 - Math.floor(aqi / 5)),
          };
          this.wards.set(id, updatedWard);
          console.log(`[AQI] ${ward.name} → ${aqi} (live)`);
        } else {
          // If individual ward fetch fails, we'll handle estimation in a second pass 
          // to ensure we use the freshest nearby data.
          console.warn(`[AQI] ${ward.name} feed failed or no data. Marking for estimation.`);
        }
      } catch (err) {
        console.error(`[AQI] Fetch failed for ward ${ward.name}:`, err);
      }
      
      // Small delay to avoid hammering the API too hard in one burst
      await new Promise(r => setTimeout(r, 50)); 
    }

    // Second pass: Estimation for wards that still have 0 or failed
    for (const [id, ward] of this.wards) {
      if (ward.aqi === 0 || ward.aqi === null) {
        let nearestWard: Ward | null = null;
        let minDistance = Infinity;

        for (const [otherId, otherWard] of this.wards) {
          if (id === otherId || !otherWard.aqi || otherWard.aqi === 0) continue;
          
          const dist = turf.distance(
            turf.point([ward.longitude, ward.latitude]),
            turf.point([otherWard.longitude, otherWard.latitude])
          );

          if (dist < minDistance) {
            minDistance = dist;
            nearestWard = otherWard;
          }
        }

        if (nearestWard) {
          const estimatedAqi = nearestWard.aqi;
          this.wards.set(id, {
            ...ward,
            aqi: estimatedAqi,
            pm25: nearestWard.pm25,
            pm10: nearestWard.pm10,
            no2: nearestWard.no2,
            wprs: nearestWard.wprs,
          });
          console.log(`[AQI] ${ward.name} → ${estimatedAqi} (estimated from ${nearestWard.name})`);
        }
      }
    }

    this.lastUpdated = new Date();
  }

  async getLastUpdated() {
    return this.lastUpdated;
  }

  async getUser(id: string) {
    return this.users.get(id);
  }

  async getUserByUsername(username: string) {
    return [...this.users.values()].find((u) => u.username === username);
  }

  async createUser(insertUser: InsertUser) {
    const id = (this.users.size + 1).toString();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getWards() {
    return [...this.wards.values()];
  }

  async getWard(id: number) {
    return this.wards.get(id);
  }

  async updateWard(id: number, updates: Partial<Ward>) {
    const ward = this.wards.get(id);
    if (!ward) throw new Error("Ward not found");
    const updated = { ...ward, ...updates };
    this.wards.set(id, updated);
    return updated;
  }

  async createReport(insertReport: InsertReport) {
    const id = this.reportIdCounter++;
    const report: Report = {
      ...insertReport,
      id,
      timestamp: new Date(),
      verified: false,
    };
    this.reports.set(id, report);
    return report;
  }

  async getReportsByWard(wardId: number) {
    return [...this.reports.values()].filter(r => r.wardId === wardId);
  }

  async updateReportVerification(id: number, verified: boolean) {
    const report = this.reports.get(id);
    if (!report) throw new Error("Report not found");
    const updated = { ...report, verified };
    this.reports.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
