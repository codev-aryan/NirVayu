import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type Ward, type SimulationResult, type CitizenPlanResponse, type CitizenPlanRequest, type SimulationRequest } from "@shared/schema";

// Helper for type-safe fetch with schema validation
async function fetchAndValidate<T>(url: string, schema: any): Promise<T> {
  const res = await fetch(url, { credentials: "include" });
  if (!res.ok) throw new Error(`Fetch failed: ${res.statusText}`);
  const data = await res.json();
  return schema.parse(data);
}

// GET /api/wards
export function useWards() {
  return useQuery({
    queryKey: [api.wards.list.path],
    queryFn: async () => {
      const res = await fetch(api.wards.list.path, { credentials: "include" });
      if (!res.ok) throw new Error(`Fetch failed: ${res.statusText}`);
      return await res.json() as { wards: Ward[], lastUpdated: string };
    },
    refetchInterval: 3000, // Poll every 3 seconds as requested
  });
}

// GET /api/wards/:id
export function useWard(id: number) {
  return useQuery({
    queryKey: [api.wards.get.path, id],
    queryFn: () => {
      const url = buildUrl(api.wards.get.path, { id });
      return fetchAndValidate<Ward>(url, api.wards.get.responses[200]);
    },
    enabled: !!id,
    refetchInterval: 10000, // Faster poll for active ward
  });
}

// POST /api/wards/:id/controls
export function useUpdateControls() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, controls }: { id: number; controls: string[] }) => {
      const url = buildUrl(api.wards.updateControls.path, { id });
      const res = await fetch(url, {
        method: api.wards.updateControls.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ controls }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update controls");
      return api.wards.updateControls.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.wards.get.path, data.id], data);
      queryClient.invalidateQueries({ queryKey: [api.wards.list.path] });
    },
  });
}

// POST /api/wards/:id/emergency
export function useToggleEmergency() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, enabled }: { id: number; enabled: boolean }) => {
      const url = buildUrl(api.wards.toggleEmergency.path, { id });
      const res = await fetch(url, {
        method: api.wards.toggleEmergency.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to toggle emergency mode");
      return api.wards.toggleEmergency.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.wards.get.path, data.id], data);
      queryClient.invalidateQueries({ queryKey: [api.wards.list.path] });
    },
  });
}

// POST /api/wards/:id/simulate
export function useSimulatePolicy() {
  return useMutation({
    mutationFn: async ({ id, params }: { id: number; params: SimulationRequest }) => {
      const url = buildUrl(api.wards.simulate.path, { id });
      const res = await fetch(url, {
        method: api.wards.simulate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Simulation failed");
      return api.wards.simulate.responses[200].parse(await res.json());
    },
  });
}

// POST /api/wards/:id/safe-plan
export function useGeneratePlan() {
  return useMutation({
    mutationFn: async ({ id, params }: { id: number; params: CitizenPlanRequest }) => {
      const url = buildUrl(api.wards.generatePlan.path, { id });
      const res = await fetch(url, {
        method: api.wards.generatePlan.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to generate plan");
      return api.wards.generatePlan.responses[200].parse(await res.json());
    },
  });
}

// POST /api/wards/:id/credits
export function useAddCredit() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, action }: { id: number; action: string }) => {
      const url = buildUrl(api.wards.addCredit.path, { id });
      const res = await fetch(url, {
        method: api.wards.addCredit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to add credit");
      return api.wards.addCredit.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.setQueryData([api.wards.get.path, data.id], data);
      queryClient.invalidateQueries({ queryKey: [api.wards.list.path] });
    },
  });
}
