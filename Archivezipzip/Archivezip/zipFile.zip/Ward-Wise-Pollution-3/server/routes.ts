import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import crypto from "crypto";
import { blockchainService } from "./blockchain";
import { insertReportSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Ward Routes ===
  
  app.get(api.wards.list.path, async (req, res) => {
    const wards = await storage.getWards();
    const lastUpdated = await storage.getLastUpdated();
    res.json({ wards, lastUpdated });
  });

  // === Pollution Reports ===

  app.post("/api/reports", async (req, res) => {
    try {
      const data = insertReportSchema.parse(req.body);
      const { mediaBase64, wardId, pollutionType } = req.body;

      if (!mediaBase64) {
        return res.status(400).json({ message: "Media is required" });
      }

      // Generate SHA-256 hash of: media, wardId, pollutionType, timestamp
      const timestamp = Date.now();
      const content = `${mediaBase64}-${wardId}-${pollutionType}-${timestamp}`;
      const mediaHash = "0x" + crypto.createHash("sha256").update(content).digest("hex");

      // Push to blockchain
      let txHash = null;
      try {
        txHash = await blockchainService.submitReport(mediaHash, wardId);
      } catch (e) {
        console.error("[Blockchain] Submit failed, storing offline:", e);
      }

      const report = await storage.createReport({
        ...data,
        mediaHash,
        txHash,
      });

      res.json({
        status: txHash ? "BLOCKCHAIN_VERIFIED" : "STORED_OFFLINE",
        txHash,
        hash: mediaHash,
        report
      });
    } catch (e) {
      console.error("[API] Report submission failed:", e);
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.get("/api/wards/:id/reports", async (req, res) => {
    const reports = await storage.getReportsByWard(Number(req.params.id));
    res.json(reports);
  });

  app.post("/api/reports/:id/verify", async (req, res) => {
    const report = await storage.updateReportVerification(Number(req.params.id), true);
    res.json(report);
  });

  app.get(api.wards.get.path, async (req, res) => {
    const ward = await storage.getWard(Number(req.params.id));
    if (!ward) return res.status(404).json({ message: "Ward not found" });
    res.json(ward);
  });

  app.post(api.wards.updateControls.path, async (req, res) => {
    try {
      const { controls } = api.wards.updateControls.input.parse(req.body);
      const ward = await storage.getWard(Number(req.params.id));
      if (!ward) return res.status(404).json({ message: "Ward not found" });
      
      const updated = await storage.updateWard(ward.id, { active_controls: controls });
      res.json(updated);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.wards.toggleEmergency.path, async (req, res) => {
    try {
      const { enabled } = api.wards.toggleEmergency.input.parse(req.body);
      const ward = await storage.getWard(Number(req.params.id));
      if (!ward) return res.status(404).json({ message: "Ward not found" });
      
      const updated = await storage.updateWard(ward.id, { emergency_mode: enabled });
      res.json(updated);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.wards.simulate.path, async (req, res) => {
    try {
      const { trafficReduction, constructionHalt, dustSuppression } = api.wards.simulate.input.parse(req.body);
      const ward = await storage.getWard(Number(req.params.id));
      if (!ward) return res.status(404).json({ message: "Ward not found" });
      
      // Simulation Logic
      let currentAqi = ward.aqi;
      let reduction = 0;
      
      // Traffic impact (~40% of pollution)
      reduction += (trafficReduction / 100) * (currentAqi * 0.4);
      
      // Construction impact (~20% of pollution)
      if (constructionHalt) {
        reduction += currentAqi * 0.2;
      }
      
      // Dust impact (~15% of pollution)
      reduction += (dustSuppression / 100) * (currentAqi * 0.15);
      
      const projectedAqi = Math.max(0, Math.round(currentAqi - reduction));
      const improvement = Math.round((reduction / currentAqi) * 100);
      
      res.json({
        projectedAqi,
        improvement,
        summary: `Implementing these policies could reduce AQI by ${Math.round(reduction)} points.`
      });
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.wards.addCredit.path, async (req, res) => {
    try {
      const { action } = api.wards.addCredit.input.parse(req.body);
      const ward = await storage.getWard(Number(req.params.id));
      if (!ward) return res.status(404).json({ message: "Ward not found" });
      
      const creditMapping = {
        public_transport: 20,
        carpooling: 10,
        plantation: 30,
        no_waste_burning: 50
      };
      
      const points = creditMapping[action];
      const newCredits = ward.citizen_credits + points;
      const newMitigation = Math.min(100, ward.mitigation_effort + Math.floor(points / 10));
      
      const updated = await storage.updateWard(ward.id, { 
        citizen_credits: newCredits,
        mitigation_effort: newMitigation
      });
      
      res.json(updated);
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.post(api.wards.generatePlan.path, async (req, res) => {
    try {
      const { ageGroup, condition, outdoorHours } = api.wards.generatePlan.input.parse(req.body);
      const ward = await storage.getWard(Number(req.params.id));
      if (!ward) return res.status(404).json({ message: "Ward not found" });
      
      const aqi = ward.aqi;
      let advice = "";
      let maskLevel = "None";
      let safeTime = "06:00 AM - 09:00 AM";
      let avoidTime = "05:00 PM - 08:00 PM";

      const preventiveMeasures = {
        personal: ["Keep windows closed during peak traffic", "Use an air purifier if available"],
        lifestyle: ["Avoid peak hour travel", "Prefer electric/public transport"],
        community: ["Support local dust control measures", "Participate in ward plantation drives"]
      };

      const checklist = {
        do: ["Check AQI before going out", "Stay hydrated"],
        avoid: ["Outdoor exercise during peak pollution", "Using wood-burning stoves"]
      };

      if (aqi < 100) {
        advice = "Air quality is acceptable. Enjoy your outdoor activities.";
        maskLevel = "None";
        checklist.do.push("Enjoy outdoor parks");
      } else if (aqi < 200) {
        advice = "Sensitive groups should limit prolonged outdoor exertion.";
        maskLevel = condition === "asthma" ? "Surgical" : "Cloth";
        preventiveMeasures.personal.push("Wear a cloth mask in dusty areas");
        checklist.avoid.push("Heavy outdoor exertion");
      } else if (aqi < 300) {
        advice = "General public should limit outdoor exertion. Wear a mask if outside.";
        maskLevel = "N95";
        avoidTime = "All Day";
        preventiveMeasures.personal.push("Strictly use N95 mask outdoors");
        checklist.do = ["Stay indoors", "Run air purifier"];
        checklist.avoid.push("All outdoor activities");
      } else {
        advice = "Emergency conditions. Avoid all outdoor activity.";
        maskLevel = "Avoid Outdoors";
        safeTime = "None";
        checklist.do = ["Seal window gaps", "Monitor health closely"];
        checklist.avoid = ["Stepping outside for any reason"];
      }

      if (ageGroup === "child" || ageGroup === "elderly") {
        advice = "Strict caution advised for your age group. " + advice;
      }

      res.json({
        safeTimeWindow: safeTime,
        avoidTimeWindow: avoidTime,
        maskLevel,
        advice,
        preventiveMeasures,
        checklist
      });
    } catch (e) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Create mock data file structure if it doesn't exist (as per requirements)
  // In a real app we might write to disk, here we just keep in memory but ensure the path concept exists
  
  return httpServer;
}
